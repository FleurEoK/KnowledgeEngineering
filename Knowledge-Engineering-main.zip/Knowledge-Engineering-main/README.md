# Knowledge Engineering

The data used for making the graphs are the seperate files in the data folder. The other data files are useful but different versions of the data. 
 
